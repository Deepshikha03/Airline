def createAirlineCountDictionary():

	file = open("airlines.csv", "r")
	file.readline()
	dic = {}
	for line in file:
		quoteStart = line.find('"')
		quoteEnd = line.rfind('"')
		airport = line[quoteStart+1:quoteEnd]
		if airport not in dic.keys():
			dic[airport] = 1
		else:
			dic[airport] += 1
	file.close()
	return dic

def findUniqueAirlineCount(dic,outputFileName):

	file=open(outputFileName,"w+")
	file.write('{\n')
	dicSize = len(dic)
	for key in dic:
		file.write('"'+key+'": '+str(dic[key]))
		dicSize -= 1
		if dicSize > 0:
			file.write(',')
		file.write('\n')

	file.write('}')
	file.close()

def findMaxAirlineCount(dic,outputFileName):

	maxAirlineCnt = -1
	maxAirlineName = ''
	for key in dic:
        	if maxAirlineCnt < dic[key]:
                	maxAirlineCnt = dic[key]
                	maxAirlineName = '"' + key + '"'

	file=open(outputFileName,"w+")
	file.write('{\n')
	if maxAirlineName != '':
		file.write(maxAirlineName + ': ' + str(maxAirlineCnt) + '\n')
	file.write('}')
	file.close()

def findMinAirlineCount(dic,outputFileName):

        minAirlineCnt = 10000000000000000
        minAirlineName = ''
        for key in dic:
                if minAirlineCnt > dic[key]:
                        minAirlineCnt = dic[key]
                        minAirlineName = '"' + key + '"'

	file=open(outputFileName,"w+")
	file.write('{\n')
	if minAirlineName != '':
        	file.write(minAirlineName + ': ' + str(minAirlineCnt) + '\n')
	file.write('}')
	file.close()

dic = createAirlineCountDictionary()
findUniqueAirlineCount(dic,"uniqueAirlineCount.json")
findMaxAirlineCount(dic,"maxAirlineCount.json")
findMinAirlineCount(dic,"minAirlineCount.json")
